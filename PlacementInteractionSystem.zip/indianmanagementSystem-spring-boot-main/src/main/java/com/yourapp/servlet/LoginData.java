package com.yourapp.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginData")
public class LoginData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("t1");  // Username
        String password = request.getParameter("t2");  // Password
        String secretKey = request.getParameter("t3"); // Secret key
        String role = request.getParameter("role");     // Role

        // Sample validation logic (Replace with your actual validation)
        boolean isValidUser = validateUser(username, password, secretKey, role);

        if (isValidUser) {
            // Redirect based on role
            if ("Admin".equals(role)) {
                response.sendRedirect("AdminDashboard.jsp");
            } else if ("Student".equals(role)) {
                response.sendRedirect("navb.jsp");
            } else if ("Company".equals(role)) {
                response.sendRedirect("LoginPage.jsp");
            }
        } else {
            // Handle invalid credentials
            request.setAttribute("errorLogin", "Invalid username, password, or secret key.");
            request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
        }
    }

    // Sample validation method (implement your actual logic here)
    private boolean validateUser(String username, String password, String secretKey, String role) {
        // Implement your validation logic (e.g., checking a database)
        // This is a dummy implementation for demonstration purposes
        if ("Admin".equals(role) && "admin".equals(username) && "admin123".equals(password) && "12345".equals(secretKey)) {
            return true;
        } else if ("Student".equals(role) && "student".equals(username) && "student123".equals(password) && "12345".equals(secretKey)) {
            return true;
        } else if ("Company".equals(role) && "company".equals(username) && "company123".equals(password) && "12345".equals(secretKey)) {
            return true;
        }
        return false; // Return false for invalid credentials
    }
}

package com.klu.demo.validation;

public class UserAdmin {
	public static int admin;
	public static int user;
	public static int isAdmin;

	

}
